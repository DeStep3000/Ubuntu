#include "lamp_driver.h"
#include <stdio.h>
#include <unistd.h>

static int isLampOn = 0;
static int canChangeBrightness = 0;

void turnOnLamp() {
    if (isLampOn) {
        printf("Лампа уже включена\n");
    } else {
        isLampOn = 1;
        canChangeBrightness = 1;
        printf("Лампа включена\n");
    }
}

void turnOffLamp() {
    if (isLampOn) {
        isLampOn = 0;
        canChangeBrightness = 0;
        printf("Лампа выключена\n");
    } else {
        printf("Лампа уже выключена\n");
    }
}

void setBrightness(int brightness) {
    if (canChangeBrightness) {
        printf("Яркость лампы установлена на %d\n", brightness);
    } else {
        printf("Невозможно изменить яркость. Лампа выключена\n");
    }
}
