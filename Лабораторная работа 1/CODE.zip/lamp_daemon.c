#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <string.h>
#include "lamp_driver.h"

#define FIFO_PATH "/home/destep/Документы/ARC/fifo"  // Полный путь к файлу FIFO

// Флаги состояния лампы
int isLampOn = 0;      // 1, если лампа включена, 0 в противном случае
int canChangeBrightness = 0;  // 1, если можно изменять яркость, 0 в противном случае

void handleCommand(const char* command) {
    if (strcmp(command, "@on") == 0) {
        if (!isLampOn) {
            turnOnLamp();
            isLampOn = 1;
            canChangeBrightness = 1;
        } else {
            printf("Лампа уже включена\n");
        }
    } else if (strcmp(command, "@off") == 0) {
        if (isLampOn) {
            turnOffLamp();
            isLampOn = 0;
            canChangeBrightness = 0;
        } else {
            printf("Лампа уже выключена\n");
        }
    } else if (strncmp(command, "@setlight", 9) == 0 && strlen(command) > 9) {
        if (isLampOn) {
            int brightness = atoi(command + 9);
            setBrightness(brightness);
        } else {
            printf("Невозможно изменить яркость. Лампа выключена\n");
        }
    } else {
        printf("Неизвестная команда\n");
    }
}

int main() {
    // Создание FIFO (именованного канала)
    mkfifo(FIFO_PATH, 0666);

    // Открытие FIFO в режиме чтения/записи
    int fifo_fd = open(FIFO_PATH, O_RDWR);

    if (fifo_fd == -1) {
        printf("Ошибка открытия FIFO\n");
        return 1;
    }

    // Основной цикл демона
    while (1) {
        // Чтение команды из FIFO
        char command[100];
        ssize_t bytesRead = read(fifo_fd, command, sizeof(command));

        // Проверка на успешное чтение
        if (bytesRead > 0) {
            // Убираем символ новой строки, если он присутствует
            if (command[bytesRead - 1] == '\n') {
                command[bytesRead - 1] = '\0';
            }

            // Обработка команды
            handleCommand(command);
        }
    }

    // Закрытие и удаление FIFO
    close(fifo_fd);
    unlink(FIFO_PATH);

    return 0;
}

