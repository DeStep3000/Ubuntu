#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <string.h>

#define FIFO_PATH "/home/destep/Документы/ARC/fifo"  // Полный путь к файлу FIFO
#define MAX_COMMAND_LENGTH 100

void printCommands() {
    printf("Список команд:\n");
    printf("@on - Включить лампу\n");
    printf("@off - Выключить лампу\n");
    printf("@setlight<яркость> - Изменить яркость лампы (от 0 до 100)\n");
    printf("@stop - Завершить работу клиента и демона\n");
    printf("\n");
}

int isCommandValid(const char* command) {
    if (strcmp(command, "@on") == 0 ||
        strcmp(command, "@off") == 0 ||
        (strncmp(command, "@setlight", 9) == 0 && strlen(command) > 9) ||
        strcmp(command, "@stop") == 0) {
        return 1;
    }
    return 0;
}

int main() {
    // Открытие FIFO в режиме записи
    int fifo_fd = open(FIFO_PATH, O_WRONLY);

    if (fifo_fd == -1) {
        printf("Ошибка открытия FIFO\n");
        return 1;
    }

    printCommands(); // Вывод списка команд

    char command[MAX_COMMAND_LENGTH];

    while (1) {
        printf("Введите команду: ");
        fgets(command, sizeof(command), stdin);

        // Убираем символ новой строки, если он присутствует
        if (command[strlen(command) - 1] == '\n') {
            command[strlen(command) - 1] = '\0';
        }

        if (strcmp(command, "@stop") == 0) {
            // Отправляем команду "@stop" для завершения работы клиента и демона
            write(fifo_fd, command, strlen(command));
            break; // Выходим из цикла
        }

        if (isCommandValid(command)) {
            write(fifo_fd, command, strlen(command));
        } else {
            printf("Неизвестная команда\n");
        }
    }

    // Закрытие FIFO
    close(fifo_fd);

    return 0;
}

