#ifndef LAMP_DRIVER_H
#define LAMP_DRIVER_H

// Функция для включения лампы
void turnOnLamp();

// Функция для выключения лампы
void turnOffLamp();

// Функция для регулировки яркости лампы
void setBrightness(int brightness);

#endif  // LAMP_DRIVER_H